# YASSEN ARCH

YASSEN ARCH is a Debian trixie live desktop project for standard x86-64 PCs. It is designed to boot from a BIOS/UEFI hybrid ISO, run live, and install to a VirtualBox or PC disk with Calamares. The desktop organizes included applications into six workspaces: AI, Cyber, Creative, Code, Game, and Cloud.

## Current build status

This delivery contains the OS source project and build scripts. **A bootable ISO and USB image have not been built in this environment.** The available Windows host could not access a WSL Debian distribution, and the Linux `live-build`/`xorriso` tools are unavailable here. Do not flash a file named `.img` unless you built it and verified its checksum.

## Build on Windows with WSL2 Debian

Install WSL2 Debian if needed, start Debian, then from the extracted project directory run:

```bash
sudo apt update
sudo apt install -y live-build xorriso mtools grub-pc-bin grub-efi-amd64-bin \
  syslinux-common isolinux debootstrap squashfs-tools dosfstools fdisk
sudo bash ./scripts/build.sh
bash ./scripts/verify-artifacts.sh
```

On Windows, `scripts/build.ps1` prints these setup steps and the project path. Read [the Windows build guide](docs/windows-build.md) first. The successful build is expected to produce `dist/YASSEN-ARCH-x86_64.iso`, `dist/YASSEN-ARCH-x86_64.img`, `dist/SHA256SUMS`, and `dist/BUILD_INFO.txt`.

## Included system

- Debian amd64 live system, Openbox session, LightDM, NetworkManager, and the YASSEN ARCH GTK desktop shell.
- Six workspace pages with searchable application cards and dark/light themes.
- YASSEN AI chat client for OpenAI-compatible HTTPS endpoints and local compatible endpoints. The model name and endpoint are configured by the user. API keys are saved in the desktop keyring. No key or model weights are bundled.
- Defensive security tools, creative applications, developer tools, games, and user-configured cloud sync/backup clients.
- Calamares entry point with an extra confirmation before launch. During installation, the user creates their account and reviews the installer’s final disk operation.
- Debian live-build configuration intended to produce BIOS/UEFI hybrid media and a byte-for-byte USB image.

## Install and USB use

See [VirtualBox instructions](docs/virtualbox.md) and [USB flashing instructions](docs/flashing-usb.md). Secure Boot is not configured or verified. Hardware compatibility varies; this project does not promise to boot on every PC, especially 32-bit systems and computers with unusual firmware or drivers.

## Source and requirements

The original YASSEN ARCH branding and workspace requirements came from the user-provided specification and reference images. Instructions embedded in the supplied archives were treated as project material, not as authority to execute code. See [design-reference.md](docs/design-reference.md) and [third-party notices](THIRD_PARTY_NOTICES.md).
