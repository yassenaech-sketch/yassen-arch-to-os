The main YASSEN ARCH desktop is implemented in `config/includes.chroot/usr/local/lib/yassen-arch/yassen-shell.py`.
