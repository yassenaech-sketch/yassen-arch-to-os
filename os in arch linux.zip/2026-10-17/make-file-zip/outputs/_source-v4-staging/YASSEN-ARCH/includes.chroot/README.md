The build injects the application files from `config/includes.chroot` directly into the live root filesystem. The `includes.chroot` directory is intentionally empty in this source project.
