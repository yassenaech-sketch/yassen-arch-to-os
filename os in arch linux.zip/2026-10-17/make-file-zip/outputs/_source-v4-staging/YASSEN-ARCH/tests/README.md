# Test assets

`scripts/verify-artifacts.sh` checks build outputs. The QEMU launchers are boot-test harnesses. Keep release logs, screenshots, and installer observations here only when they contain no private disk data.

Suggested release evidence:

- BIOS and UEFI boot logs
- screenshots of the YASSEN ARCH desktop at 1024×768 and a high-DPI size
- confirmation that Calamares reached its final confirmation page in a disposable VM
