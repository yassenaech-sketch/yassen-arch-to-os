The package manifest is maintained in `config/package-lists/yassen-arch.list.chroot`. Review the Debian package list and build on Debian before creating release media.
