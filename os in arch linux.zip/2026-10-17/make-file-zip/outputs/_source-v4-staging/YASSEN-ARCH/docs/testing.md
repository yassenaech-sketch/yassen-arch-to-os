# Testing and release status

## Checks still required on a Linux build host

| Check | Command or method | Status in this delivery |
| --- | --- | --- |
| Shell syntax | `bash -n scripts/*.sh` | Not run; WSL Bash access was denied |
| Python syntax | Python `compile()` on all YASSEN ARCH `.py` files | Passed |
| Package resolution and live-build | `sudo ./scripts/build.sh` | Not run; WSL denied access in this environment |
| ISO checksums and boot catalog | `./scripts/verify-artifacts.sh` | Not run; there is no built ISO/image |
| BIOS/UEFI boot | QEMU scripts with QEMU/OVMF | Not run |
| VirtualBox install | Disposable VM; inspect final Calamares confirmation | Not run |

## Release checks

After a successful build, retain the exact `BUILD_INFO.txt` and `SHA256SUMS`. Boot in QEMU/VirtualBox under BIOS and UEFI. Test Calamares only against a disposable VM disk and confirm that its final confirmation identifies the target disk. Do not use a physical disk for automated installation checks.
