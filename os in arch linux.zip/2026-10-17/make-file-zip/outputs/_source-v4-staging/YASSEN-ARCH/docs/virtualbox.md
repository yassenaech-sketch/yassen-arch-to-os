# VirtualBox

Create a disposable VM with 2 CPUs, 4 GB RAM, and a 32 GB virtual disk. Attach `dist/YASSEN-ARCH-x86_64.iso` as an optical disk. Run `scripts/create-virtualbox-vm.ps1` on Windows when VirtualBox is installed:

```powershell
.\scripts\create-virtualbox-vm.ps1
```

Use `-EnableEfi` to test UEFI boot. Start with **Try YASSEN ARCH**, then open **Welcome & Install** if you want to review the installer. The user account is created inside Calamares. Review its target disk and final confirmation screen; only proceed with disk changes on a disposable VM disk.

The ISO has not been built or boot-tested in the current delivery. Secure Boot is not verified.
