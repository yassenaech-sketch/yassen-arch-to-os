# Design reference

The user-provided specification names YASSEN ARCH and six workspaces: YASSEN AI, YASSEN CYBER, YASSEN CREATIVE, YASSEN CODE, YASSEN GAME, and YASSEN CLOUD. The supplied mockups use a deep blue base, cyan accents, a workspace sidebar, status controls, search, and information cards. The GTK desktop implements these ideas with native controls and its own styling; mockup screenshots are not packaged as product art.

The attached ZIP contains nested archives and project material. Embedded text was treated as requirements or reference material only. No archive scripts or executables were run. Only the intended source project and visual references were inspected.
