# Architecture

```text
UEFI firmware / legacy BIOS
        │
 GRUB EFI + BIOS boot path in a live-build hybrid ISO
        │
 Debian amd64 kernel + live-boot + squashfs root
        │
 LightDM → Openbox session → YASSEN ARCH GTK workspace shell
        │                              ├→ Debian applications
        │                              ├→ YASSEN AI provider client
        │                              └→ Calamares installer
```

`live-build` owns boot-media creation and package installation. `config/includes.chroot` injects YASSEN ARCH application files into the live root; the chroot hook installs launchers and defaults. LightDM starts an ephemeral live user in Openbox. Calamares is offered from the welcome screen after an additional confirmation. The installed account is entered in Calamares.

The build script requests a Debian amd64 `iso-hybrid`. It creates the USB image as a byte-for-byte copy of that output only after `xorriso` confirms hybrid boot metadata. BIOS/UEFI compatibility, package resolution, installer behavior, and booting remain unverified until the project is built and tested on Linux.

YASSEN AI is a desktop client for a user-configured OpenAI-compatible endpoint. User API keys are stored in the desktop keyring. Cloud providers are also configured by the user; no account is connected by default. Local AI models are not bundled.
