# Build YASSEN ARCH on Windows with WSL2 Debian

The boot media must be assembled by Debian `live-build`; PowerShell cannot create this Linux image natively. This workspace could not access WSL during this run, so the ISO and USB image are not included until you build them successfully.

## 1. Install WSL2 Debian

Open **PowerShell as Administrator** and run:

```powershell
wsl --install -d Debian
```

Restart Windows if requested, open Debian from the Start menu, and create its Linux user.

## 2. Install build tools

In the Debian terminal:

```bash
sudo apt update
sudo apt install -y live-build xorriso mtools grub-pc-bin grub-efi-amd64-bin \
  syslinux-common isolinux debootstrap squashfs-tools dosfstools fdisk
```

## 3. Build and verify

Extract this project somewhere accessible from WSL. In Debian, change to its `/mnt/<drive>/.../yassen-arch` path and run:

```bash
sudo bash ./scripts/build.sh
bash ./scripts/verify-artifacts.sh
```

A successful build creates `dist/YASSEN-ARCH-x86_64.iso`, `dist/YASSEN-ARCH-x86_64.img`, `dist/SHA256SUMS`, and `dist/BUILD_INFO.txt`. The build downloads Debian packages and needs several gigabytes of disk space. If build or verification fails, do not rename partial files as finished media.

## 4. Test safely

Attach the ISO to a disposable VirtualBox VM first. Start the live desktop, open **Welcome & Install**, and inspect Calamares through its final confirmation step using only the VM disk. Do not approve destructive disk actions during this check.

## 5. Flash USB after verification

Compare the image checksum with `dist/SHA256SUMS`, then use Rufus in DD mode or Balena Etcher. Selecting a USB drive for flashing erases that drive. See [flashing-usb.md](flashing-usb.md).
