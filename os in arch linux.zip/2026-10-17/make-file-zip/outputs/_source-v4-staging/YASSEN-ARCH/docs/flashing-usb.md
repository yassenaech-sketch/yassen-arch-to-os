# Flashing a YASSEN ARCH USB

**Flashing erases the selected USB drive.** The `.img` is intended as a whole-device image; do not unpack it or copy its files onto an already formatted stick.

1. Build the project and make sure `./scripts/verify-artifacts.sh` succeeds.
2. Compare the image checksum with `dist/SHA256SUMS`.
3. In Balena Etcher, choose `YASSEN-ARCH-x86_64.img`, select the removable USB drive, and flash it. In Rufus, choose DD mode if prompted.
4. On Linux, identify the whole removable device carefully, then run:

```bash
sudo dd if=dist/YASSEN-ARCH-x86_64.img of=/dev/sdX bs=4M conv=fsync status=progress
```

Replace `/dev/sdX` with the whole USB device, never a partition such as `/dev/sdX1`. The command permanently overwrites the selected device.

YASSEN ARCH targets standard x86-64 PCs with BIOS or UEFI. Secure Boot and universal hardware compatibility are not verified.
