# Build guide

## Supported host

Build in a current Debian stable host, Debian VM, or WSL2 Debian. PowerShell cannot natively run Debian `live-build` reliably; `scripts/build.ps1` prints the supported route.

```bash
sudo apt update
sudo apt install -y live-build xorriso mtools grub-pc-bin grub-efi-amd64-bin \
  syslinux-common qemu-system-x86 ovmf fdisk
cd yassen-arch
sudo bash ./scripts/build.sh
```

The build needs network access to Debian package mirrors. It creates `build/live-build/` and exactly these primary outputs:

```text
dist/YASSEN-ARCH-x86_64.iso
dist/YASSEN-ARCH-x86_64.img
dist/SHA256SUMS
dist/BUILD_INFO.txt
```

It also writes diagnostic reports during verification. Dependencies are normal Debian packages: `live-build` creates bootable media; GRUB/Syslinux provide BIOS/UEFI paths; `xorriso` writes and examines the ISO; `mtools` reads FAT images; QEMU/OVMF are test-only. When building from a Windows-mounted folder, use `bash ./scripts/build.sh` so execution does not depend on Windows file mode bits.

Before release, pin `trixie` to a dated Debian snapshot in your own APT configuration and retain the generated `BUILD_INFO.txt` and `SHA256SUMS`. This repository intentionally does not silently download arbitrary binary blobs.
