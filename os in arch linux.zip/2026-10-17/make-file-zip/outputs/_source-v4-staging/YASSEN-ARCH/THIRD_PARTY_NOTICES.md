# Third-party notices

YASSEN ARCH is an original project built from Debian packages and upstream desktop applications. Each bundled program keeps its own copyright and license; consult its package documentation or Debian copyright files on the installed system.

The YASSEN ARCH shell and illustrative application layouts are developed for this project. Do not infer that Debian, GNOME, OpenAI, Calamares, or any application vendor endorses YASSEN ARCH. Brand names identify applications or services users may choose to configure.

No API key, private account data, or model weights are part of the OS source package.
