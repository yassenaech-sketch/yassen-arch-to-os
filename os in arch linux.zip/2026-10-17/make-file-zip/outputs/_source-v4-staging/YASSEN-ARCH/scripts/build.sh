#!/usr/bin/env bash
# Build YASSEN ARCH from a Debian trixie/WSL2 Debian environment.
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

need() { command -v "$1" >/dev/null 2>&1 || { echo "Missing required tool: $1" >&2; exit 2; }; }
[[ "$(id -u)" -eq 0 ]] || { echo "Run with sudo: sudo ./scripts/build.sh" >&2; exit 2; }
need lb; need xorriso; need sha256sum
chmod 0755 "$ROOT/config/hooks/live/010-yassen-arch.hook.chroot"

mkdir -p build dist
rm -rf build/live-build
mkdir -p build/live-build
cp -a config build/live-build/config
cd build/live-build

lb config noauto \
  --architectures amd64 \
  --distribution trixie \
  --archive-areas "main contrib non-free-firmware" \
  --binary-images iso-hybrid \
  --bootloaders "grub-efi syslinux" \
  --firmware-binary true \
  --debian-installer live \
  --memtest memtest86+ \
  --apt-indices false \
  --image-name YassenArch \
  --iso-application "YASSEN ARCH" \
  --iso-publisher "YASSEN ARCH contributors" \
  --iso-volume "YASSEN_ARCH"

lb build

ISO="$(find . -maxdepth 1 -type f \( -name '*.hybrid.iso' -o -name '*.iso' \) | head -n1)"
[[ -n "$ISO" && -f "$ISO" ]] || { echo "live-build completed without an ISO" >&2; exit 1; }
cp "$ISO" "$ROOT/dist/YASSEN-ARCH-x86_64.iso"
"$ROOT/scripts/make-usb-image.sh" "$ROOT/dist/YASSEN-ARCH-x86_64.iso" "$ROOT/dist/YASSEN-ARCH-x86_64.img"

cd "$ROOT"
sha256sum dist/YASSEN-ARCH-x86_64.iso dist/YASSEN-ARCH-x86_64.img > dist/SHA256SUMS
{
  echo "name=YASSEN ARCH"
  echo "distribution=Debian trixie"
  echo "architecture=amd64"
  echo "built_at_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "source_revision=uncommitted-source"
  echo "live_build=$(lb --version | head -n1)"
  echo "kernel=$(dpkg-query -W -f='${Version}' linux-image-amd64 2>/dev/null || echo resolved-in-chroot)"
  echo "configuration_sha256=$(find config -type f -print0 | sort -z | xargs -0 sha256sum | sha256sum | cut -d' ' -f1)"
} > dist/BUILD_INFO.txt

"$ROOT/scripts/verify-artifacts.sh"
echo "Build complete: $ROOT/dist/YASSEN-ARCH-x86_64.iso and $ROOT/dist/YASSEN-ARCH-x86_64.img"
