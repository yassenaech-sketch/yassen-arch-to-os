#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
for file in dist/YASSEN-ARCH-x86_64.iso dist/YASSEN-ARCH-x86_64.img dist/SHA256SUMS dist/BUILD_INFO.txt; do
  [[ -s "$file" ]] || { echo "Missing or empty: $file" >&2; exit 1; }
done
sha256sum --check dist/SHA256SUMS
command -v xorriso >/dev/null || { echo "xorriso required for ISO inspection" >&2; exit 2; }
xorriso -indev dist/YASSEN-ARCH-x86_64.iso -report_el_torito plain | tee dist/EL_TORITO_REPORT.txt
if command -v fdisk >/dev/null; then
  fdisk -l dist/YASSEN-ARCH-x86_64.img | tee dist/USB_PARTITIONS.txt
fi
if command -v mdir >/dev/null; then
  mdir -i dist/YASSEN-ARCH-x86_64.img@@1 ::/EFI/BOOT/BOOTX64.EFI || true
fi
echo "Artifact structure checks completed. Run the QEMU scripts for boot checks."
