#!/usr/bin/env bash
# A Debian live-build hybrid ISO is byte-for-byte flashable as a whole-device image.
set -Eeuo pipefail
SOURCE="${1:?usage: make-usb-image.sh SOURCE.iso DESTINATION.img}"
DESTINATION="${2:?usage: make-usb-image.sh SOURCE.iso DESTINATION.img}"
[[ -f "$SOURCE" ]] || { echo "ISO not found: $SOURCE" >&2; exit 2; }
command -v xorriso >/dev/null || { echo "xorriso is required to inspect the hybrid ISO" >&2; exit 2; }

REPORT="$(xorriso -indev "$SOURCE" -report_el_torito as_mkisofs 2>&1 || true)"
if ! grep -Eq -- '-isohybrid-mbr|-isohybrid-gpt-basdat|-isohybrid-gpt-hfsplus' <<<"$REPORT"; then
  echo "Refusing to copy a non-hybrid ISO. Build with live-build --binary-images iso-hybrid." >&2
  exit 1
fi
cp --reflink=auto "$SOURCE" "$DESTINATION"
sync
echo "USB-ready whole-device image created: $DESTINATION"
