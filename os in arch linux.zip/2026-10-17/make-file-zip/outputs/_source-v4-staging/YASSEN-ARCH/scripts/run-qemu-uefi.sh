#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
command -v qemu-system-x86_64 >/dev/null || { echo "Install qemu-system-x86" >&2; exit 2; }
OVMF_CODE="${OVMF_CODE:-/usr/share/OVMF/OVMF_CODE.fd}"
[[ -r "$OVMF_CODE" ]] || { echo "OVMF firmware not found. Set OVMF_CODE=/path/to/OVMF_CODE.fd" >&2; exit 2; }
exec qemu-system-x86_64 -m 4096 -smp 2 -bios "$OVMF_CODE" -cdrom "$ROOT/dist/YASSEN-ARCH-x86_64.iso" -boot d -enable-kvm
