#!/usr/bin/env python3
"""Simple YASSEN ARCH desktop preferences and system settings launcher."""
import json
import os
import subprocess
from pathlib import Path

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

CONFIG = Path.home() / ".config" / "yassen-arch" / "settings.json"


def current_theme():
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8")).get("theme", "dark")
    except (OSError, ValueError, TypeError):
        return "dark"


class Settings(Gtk.Window):
    def __init__(self):
        super().__init__(title="YASSEN ARCH Settings")
        self.set_default_size(640, 520)
        self.set_border_width(24)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        self.add(box)
        title = Gtk.Label(label="Settings", xalign=0)
        title.get_style_context().add_class("title-1")
        box.pack_start(title, False, False, 0)
        box.pack_start(Gtk.Label(label="Personalize the desktop and open system panels.", xalign=0), False, False, 0)

        box.pack_start(Gtk.Label(label="Appearance", xalign=0), False, False, 8)
        self.dark = Gtk.RadioButton.new_with_label_from_widget(None, "Dark blue")
        self.light = Gtk.RadioButton.new_with_label_from_widget(self.dark, "Light")
        selected = current_theme()
        (self.light if selected == "light" else self.dark).set_active(True)
        box.pack_start(self.dark, False, False, 0)
        box.pack_start(self.light, False, False, 0)
        save = Gtk.Button(label="Apply appearance")
        save.connect("clicked", self.save_theme)
        box.pack_start(save, False, False, 0)
        self.status = Gtk.Label(label="The shell updates automatically when the theme changes.", xalign=0)
        self.status.set_line_wrap(True)
        box.pack_start(self.status, False, False, 0)

        box.pack_start(Gtk.Separator(), False, False, 8)
        box.pack_start(Gtk.Label(label="System panels", xalign=0), False, False, 4)
        for label, command in (
            ("Network", ("nm-connection-editor",)),
            ("Display", ("xfce4-display-settings",)),
            ("Sound", ("pavucontrol",)),
            ("Keyboard", ("xfce4-keyboard-settings",)),
        ):
            button = Gtk.Button(label=label)
            button.set_halign(Gtk.Align.START)
            button.connect("clicked", lambda _button, cmd=command: self.launch(cmd))
            box.pack_start(button, False, False, 0)

        note = Gtk.Label(label="Create or change your installed user account in the YASSEN ARCH installer.", xalign=0)
        note.set_line_wrap(True)
        note.get_style_context().add_class("muted")
        box.pack_start(note, False, False, 8)

    def save_theme(self, *_args):
        theme = "light" if self.light.get_active() else "dark"
        CONFIG.parent.mkdir(parents=True, exist_ok=True)
        CONFIG.write_text(json.dumps({"theme": theme}, indent=2) + "\n", encoding="utf-8")
        os.chmod(CONFIG, 0o600)
        self.status.set_text("Appearance updated.")

    def launch(self, command):
        try:
            subprocess.Popen(command, start_new_session=True)
        except FileNotFoundError:
            self.status.set_text(f"This system panel is not installed: {command[0]}")


if __name__ == "__main__":
    window = Settings()
    window.connect("destroy", Gtk.main_quit)
    window.show_all()
    Gtk.main()
