#!/usr/bin/env python3
"""YASSEN AI client for OpenAI-compatible remote or local endpoints."""
import argparse
import json
import os
import subprocess
import threading
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import GLib, Gtk

APP_NAME = "YASSEN ARCH"
SERVICE = "yassen-arch"
ACCOUNT = "ai-api"
CONFIG_PATH = Path.home() / ".config" / "yassen-arch" / "ai.json"
SYSTEM_PROMPT = (
    "You are YASSEN AI, a helpful assistant inside a Linux desktop. "
    "Help with ideas, code, and workflow plans. Never claim to have executed a command, "
    "changed a file, or connected a service. Give commands as suggestions for the user "
    "to review; do not encourage running destructive commands without explaining them."
)
QUICK_PROMPTS = {
    "Ideas": "Help me explore this idea. Ask a short clarifying question if useful:",
    "Code": "Help me design or write code for this task. Explain important choices:",
    "Workflow": "Turn this task into a clear workflow with review points:",
}


def read_config():
    try:
        value = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        return {
            "base_url": value.get("base_url", "https://api.openai.com/v1"),
            "model": value.get("model", ""),
        }
    except (OSError, ValueError, TypeError):
        return {"base_url": "https://api.openai.com/v1", "model": ""}


def save_secret(value):
    if not value:
        return True
    if not shutil_which("secret-tool"):
        raise RuntimeError("The system keyring is unavailable. Install libsecret-tools and unlock the desktop keyring first.")
    result = subprocess.run(
        ("secret-tool", "store", "--label=YASSEN AI API key", "service", SERVICE, "account", ACCOUNT),
        input=value + "\n", text=True, capture_output=True, timeout=10, check=False,
    )
    if result.returncode != 0:
        raise RuntimeError("The key could not be saved to the desktop keyring.")
    return True


def shutil_which(name):
    from shutil import which
    return which(name)


def get_secret():
    value = os.environ.get("OPENAI_API_KEY")
    if value:
        return value
    if not shutil_which("secret-tool"):
        return ""
    result = subprocess.run(
        ("secret-tool", "lookup", "service", SERVICE, "account", ACCOUNT),
        capture_output=True, text=True, timeout=10, check=False,
    )
    return result.stdout.strip() if result.returncode == 0 else ""


def validate_endpoint(base_url):
    parsed = urlparse(base_url.strip())
    if parsed.scheme == "https" and parsed.netloc:
        return base_url.strip().rstrip("/")
    if parsed.scheme == "http" and parsed.hostname in {"localhost", "127.0.0.1", "::1"}:
        return base_url.strip().rstrip("/")
    raise ValueError("Use HTTPS for online endpoints. HTTP is allowed only for localhost model servers.")


def request_completion(config, messages):
    base_url = validate_endpoint(config["base_url"])
    model = config["model"].strip()
    if not model:
        raise ValueError("Open Settings and enter a model name for your provider.")
    if len(messages[-1]["content"]) > 32000:
        raise ValueError("That message is too long. Keep each prompt under 32,000 characters.")
    token = get_secret()
    local_endpoint = urlparse(base_url).hostname in {"localhost", "127.0.0.1", "::1"}
    if not token and not local_endpoint:
        raise ValueError("No API key is saved. Open Settings and save a key in the desktop keyring.")
    body = json.dumps({"model": model, "messages": messages, "stream": False}).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    request = Request(base_url + "/chat/completions", data=body, headers=headers, method="POST")
    try:
        with urlopen(request, timeout=90) as response:
            payload = json.loads(response.read(2 * 1024 * 1024).decode("utf-8"))
    except HTTPError as exc:
        # Do not expose request headers, which contain the API key.
        if exc.code in (401, 403):
            raise RuntimeError("The provider rejected the credentials. Check the key and project permissions in Settings.") from None
        raise RuntimeError(f"The provider returned HTTP {exc.code}.") from None
    except (URLError, TimeoutError) as exc:
        raise RuntimeError(f"Could not reach the configured AI endpoint: {exc.reason if isinstance(exc, URLError) else 'request timed out'}") from None
    try:
        text = payload["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        raise RuntimeError("The endpoint response did not contain a chat completion.") from None
    if not isinstance(text, str) or not text.strip():
        raise RuntimeError("The provider returned an empty response.")
    return text.strip()


class SettingsDialog(Gtk.Dialog):
    def __init__(self, parent, config):
        super().__init__(title="YASSEN AI Settings", transient_for=parent, modal=True)
        self.add_buttons("Cancel", Gtk.ResponseType.CANCEL, "Save", Gtk.ResponseType.OK)
        self.set_default_size(580, 360)
        box = self.get_content_area()
        box.set_spacing(12)
        box.set_margin_top(18); box.set_margin_bottom(18); box.set_margin_start(18); box.set_margin_end(18)
        box.pack_start(Gtk.Label(label="Provider endpoint", xalign=0), False, False, 0)
        self.endpoint = Gtk.Entry(); self.endpoint.set_text(config["base_url"])
        self.endpoint.set_placeholder_text("https://api.openai.com/v1 or a local /v1 endpoint")
        box.pack_start(self.endpoint, False, False, 0)
        box.pack_start(Gtk.Label(label="Model name", xalign=0), False, False, 0)
        self.model = Gtk.Entry(); self.model.set_text(config["model"])
        self.model.set_placeholder_text("Enter the model name supported by your provider")
        box.pack_start(self.model, False, False, 0)
        box.pack_start(Gtk.Label(label="API key (optional for local endpoints)", xalign=0), False, False, 0)
        self.key = Gtk.Entry(); self.key.set_visibility(False); self.key.set_input_purpose(Gtk.InputPurpose.PASSWORD)
        self.key.set_placeholder_text("Leave blank to keep the current key")
        box.pack_start(self.key, False, False, 0)
        note = Gtk.Label(label="Keys are saved in the unlocked desktop keyring, never in this settings file. Online endpoints must use HTTPS.", xalign=0)
        note.set_line_wrap(True); note.get_style_context().add_class("muted")
        box.pack_start(note, False, False, 0)
        self.show_all()


class YassenAI(Gtk.Window):
    def __init__(self, mode="chat"):
        super().__init__(title="YASSEN AI")
        self.set_default_size(920, 700)
        self.set_border_width(22)
        self.config = read_config()
        self.mode = mode
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14); self.add(root)
        title_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        title_row.pack_start(Gtk.Label(label="YASSEN AI", xalign=0), True, True, 0)
        settings_button = Gtk.Button(label="Settings")
        settings_button.connect("clicked", self.open_settings)
        title_row.pack_end(settings_button, False, False, 0)
        root.pack_start(title_row, False, False, 0)
        subtitle = Gtk.Label(label="AI Studio · Ideas · Code · Workflows", xalign=0)
        subtitle.get_style_context().add_class("muted"); root.pack_start(subtitle, False, False, 0)
        quick = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        for label, prompt in QUICK_PROMPTS.items():
            button = Gtk.Button(label=label)
            button.connect("clicked", lambda _b, p=prompt: self._set_quick_prompt(p))
            quick.pack_start(button, False, False, 0)
        root.pack_start(quick, False, False, 0)
        scroll = Gtk.ScrolledWindow(); scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.output = Gtk.TextView(); self.output.set_editable(False); self.output.set_cursor_visible(False); self.output.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.output.get_style_context().add_class("chat-output"); self.buffer = self.output.get_buffer(); scroll.add(self.output)
        root.pack_start(scroll, True, True, 0)
        input_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.prompt = Gtk.Entry(); self.prompt.set_placeholder_text("Ask for help, a code draft, an idea, or a workflow plan")
        self.prompt.connect("activate", self.send)
        self.send_button = Gtk.Button(label="Send"); self.send_button.connect("clicked", self.send)
        input_row.pack_start(self.prompt, True, True, 0); input_row.pack_start(self.send_button, False, False, 0)
        root.pack_start(input_row, False, False, 0)
        disclaimer = Gtk.Label(label="AI output is a suggestion. It does not run shell commands or edit files automatically.", xalign=0)
        disclaimer.set_line_wrap(True); disclaimer.get_style_context().add_class("muted"); root.pack_start(disclaimer, False, False, 0)
        if mode == "code":
            self._set_quick_prompt(QUICK_PROMPTS["Code"])
        elif mode == "workflow":
            self._set_quick_prompt(QUICK_PROMPTS["Workflow"])

    def _set_quick_prompt(self, text):
        self.prompt.set_text(text + " ")
        self.prompt.grab_focus()
        self.prompt.set_position(-1)

    def _append(self, speaker, text):
        end = self.buffer.get_end_iter()
        self.buffer.insert(end, f"{speaker}\n{text}\n\n")
        mark = self.buffer.create_mark(None, self.buffer.get_end_iter(), False)
        self.output.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)

    def open_settings(self, *_args):
        dialog = SettingsDialog(self, self.config)
        if dialog.run() == Gtk.ResponseType.OK:
            try:
                endpoint = validate_endpoint(dialog.endpoint.get_text())
                model = dialog.model.get_text().strip()
                if not model:
                    raise ValueError("Enter a model name.")
                secret = dialog.key.get_text()
                if secret:
                    save_secret(secret)
                CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
                CONFIG_PATH.write_text(json.dumps({"base_url": endpoint, "model": model}, indent=2) + "\n", encoding="utf-8")
                os.chmod(CONFIG_PATH, 0o600)
                self.config = {"base_url": endpoint, "model": model}
                self._append("YASSEN AI", "Settings saved. The API key is stored in the desktop keyring.")
            except (ValueError, OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
                self._append("Settings", str(exc))
        dialog.destroy()

    def send(self, *_args):
        text = self.prompt.get_text().strip()
        if not text:
            return
        self.prompt.set_text("")
        self._append("You", text)
        self.messages.append({"role": "user", "content": text})
        self.send_button.set_sensitive(False)
        self.send_button.set_label("Working…")
        config = dict(self.config)
        messages = list(self.messages)
        threading.Thread(target=self._request_worker, args=(config, messages), daemon=True).start()

    def _request_worker(self, config, messages):
        try:
            answer = request_completion(config, messages)
            GLib.idle_add(self._finish_request, answer, None)
        except Exception as exc:
            GLib.idle_add(self._finish_request, None, str(exc))

    def _finish_request(self, answer, error):
        self.send_button.set_sensitive(True); self.send_button.set_label("Send")
        if error:
            self._append("YASSEN AI", error)
        else:
            self.messages.append({"role": "assistant", "content": answer})
            self._append("YASSEN AI", answer)
        return False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("chat", "code", "workflow"), default="chat")
    parser.add_argument("--settings", action="store_true")
    args = parser.parse_args()
    window = YassenAI(args.mode)
    window.connect("destroy", Gtk.main_quit)
    window.show_all()
    if args.settings:
        GLib.idle_add(window.open_settings)
    Gtk.main()


if __name__ == "__main__":
    main()
