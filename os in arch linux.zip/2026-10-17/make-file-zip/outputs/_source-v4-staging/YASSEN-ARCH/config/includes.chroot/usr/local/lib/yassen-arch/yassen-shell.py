#!/usr/bin/env python3
"""YASSEN ARCH desktop and OS Switcher for the Openbox session."""
import datetime
import getpass
import json
import shutil
import subprocess
from pathlib import Path

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Notify", "0.7")
from gi.repository import Gdk, GLib, Gtk, Notify

APP_ROOT = "/usr/local/lib/yassen-arch"
MODULES = [
    ("ai", "YASSEN AI", "AI studio, coding help, ideas, and workflow planning", "applications-science"),
    ("cyber", "YASSEN CYBER", "Defensive security, local audits, and network analysis", "security-high"),
    ("creative", "YASSEN CREATIVE", "Graphics, image editing, and video production", "applications-graphics"),
    ("code", "YASSEN CODE", "Projects, terminal, source control, and vibe coding", "applications-development"),
    ("game", "YASSEN GAME", "Games and a place to manage your play library", "applications-games"),
    ("cloud", "YASSEN CLOUD", "File sync, backup, and connected services", "folder-remote"),
]

APPS = [
    {"module": "ai", "title": "AI Studio", "description": "Chat, draft code, explore ideas, and plan workflows.", "icon": "applications-science", "command": ("yassen-ai",)},
    {"module": "ai", "title": "AI Settings", "description": "Choose an online API or a local compatible endpoint.", "icon": "preferences-system", "command": ("yassen-ai", "--settings")},
    {"module": "cyber", "title": "Wireshark", "description": "Inspect traffic on networks you are authorized to analyze.", "icon": "network-wired", "command": ("wireshark",)},
    {"module": "cyber", "title": "Nmap help", "description": "Open the Nmap manual in a terminal; choose authorized lab targets yourself.", "icon": "utilities-terminal", "command": ("xfce4-terminal", "--command", "nmap --help")},
    {"module": "cyber", "title": "Local security audit", "description": "Run Lynis after reviewing its checks; it does not scan remote hosts.", "icon": "security-high", "command": ("xfce4-terminal", "--command", "sudo lynis audit system")},
    {"module": "cyber", "title": "Malware scan help", "description": "Review ClamAV scan options before selecting files.", "icon": "edit-find", "command": ("xfce4-terminal", "--command", "clamscan --help")},
    {"module": "creative", "title": "GIMP", "description": "Raster graphics and photo editing.", "icon": "gimp", "command": ("gimp",)},
    {"module": "creative", "title": "Inkscape", "description": "Vector illustration and SVG design.", "icon": "inkscape", "command": ("inkscape",)},
    {"module": "creative", "title": "Krita", "description": "Digital painting and illustration.", "icon": "krita", "command": ("krita",)},
    {"module": "creative", "title": "Kdenlive", "description": "Multitrack video editing.", "icon": "kdenlive", "command": ("kdenlive",)},
    {"module": "code", "title": "Geany", "description": "Lightweight code editor for projects and scripts.", "icon": "accessories-text-editor", "command": ("geany",)},
    {"module": "code", "title": "Terminal", "description": "Open a shell in your home folder.", "icon": "utilities-terminal", "command": ("xfce4-terminal",)},
    {"module": "code", "title": "Projects", "description": "Browse your Projects folder.", "icon": "folder", "command": ("thunar", "--working-directory", GLib.get_home_dir() + "/Projects")},
    {"module": "code", "title": "Vibe Coding", "description": "Ask YASSEN AI to help draft code; review before saving or running it.", "icon": "applications-development", "command": ("yassen-ai", "--mode", "code")},
    {"module": "game", "title": "SuperTuxKart", "description": "Open-source kart racing.", "icon": "applications-games", "command": ("supertuxkart",)},
    {"module": "game", "title": "Freeciv", "description": "Turn-based strategy game.", "icon": "applications-games", "command": ("freeciv-gtk3",)},
    {"module": "cloud", "title": "Nextcloud", "description": "Connect a server to sync your files.", "icon": "folder-remote", "command": ("nextcloud",)},
    {"module": "cloud", "title": "Backups", "description": "Choose backup locations and review the destination before starting.", "icon": "drive-harddisk", "command": ("deja-dup",)},
    {"module": "cloud", "title": "Rclone setup", "description": "Configure a cloud provider interactively; no account is connected by default.", "icon": "folder-remote", "command": ("xfce4-terminal", "--command", "rclone config")},
]


def notify(title, message):
    Notify.Notification.new(title, message, "dialog-information").show()


def launch(command):
    if not command or not shutil.which(command[0]):
        notify("YASSEN ARCH", f"This app is not installed: {command[0] if command else 'unknown'}")
        return
    try:
        subprocess.Popen(command, start_new_session=True)
    except OSError as exc:
        notify("Could not open app", str(exc))


class YassenShell(Gtk.Window):
    def __init__(self):
        super().__init__(title="YASSEN ARCH")
        self.set_default_size(1280, 820)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_icon_name("applications-system")
        self.connect("destroy", Gtk.main_quit)
        self._theme_mtime = None
        self._css_provider = None
        self._load_theme()
        self._build()
        GLib.timeout_add_seconds(10, self._refresh_status)
        GLib.timeout_add_seconds(2, self._refresh_theme)
        self._refresh_status()

    def _load_theme(self):
        path = Path.home() / ".config" / "yassen-arch" / "settings.json"
        try:
            theme = json.loads(path.read_text(encoding="utf-8")).get("theme", "dark")
        except (OSError, ValueError, TypeError):
            theme = "dark"
        css_path = APP_ROOT + ("/yassen-light.css" if theme == "light" else "/yassen-gtk.css")
        try:
            mtime = Path(css_path).stat().st_mtime
            if self._theme_mtime == (str(path), path.stat().st_mtime if path.exists() else None, css_path, mtime):
                return
            provider = Gtk.CssProvider()
            provider.load_from_path(css_path)
            if self._css_provider:
                Gtk.StyleContext.remove_provider_for_screen(Gdk.Screen.get_default(), self._css_provider)
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )
            self._css_provider = provider
            self._theme_mtime = (str(path), path.stat().st_mtime if path.exists() else None, css_path, mtime)
        except (OSError, GLib.Error):
            return

    def _refresh_theme(self):
        self._load_theme()
        return True

    def _build(self):
        outer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.add(outer)

        sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        sidebar.set_size_request(236, -1)
        sidebar.get_style_context().add_class("sidebar")
        sidebar.set_margin_top(18)
        sidebar.set_margin_bottom(18)
        sidebar.set_margin_start(14)
        sidebar.set_margin_end(10)
        outer.pack_start(sidebar, False, False, 0)

        brand = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        brand.set_margin_start(12)
        brand.set_margin_bottom(20)
        brand.pack_start(self._label("YASSEN ARCH", "brand"), False, False, 0)
        brand.pack_start(self._label("FUTURE WORKSPACE", "eyebrow"), False, False, 0)
        sidebar.pack_start(brand, False, False, 0)

        self.nav_buttons = {}
        dashboard = self._nav_button("⌂", "Workspace", "home")
        sidebar.pack_start(dashboard, False, False, 0)
        for key, title, _description, icon in MODULES:
            btn = self._nav_button(icon, title, key)
            sidebar.pack_start(btn, False, False, 0)

        spacer = Gtk.Box()
        sidebar.pack_start(spacer, True, True, 0)
        sidebar.pack_start(self._nav_button("preferences-system", "Settings", "settings"), False, False, 0)
        sidebar.pack_start(self._nav_button("help-about", "Welcome & Install", "welcome"), False, False, 0)

        main = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        main.set_margin_top(18)
        main.set_margin_end(22)
        main.set_margin_bottom(18)
        outer.pack_start(main, True, True, 0)

        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        top.get_style_context().add_class("topbar")
        top.set_margin_bottom(16)
        main.pack_start(top, False, False, 0)
        self.page_title = self._label("Workspace", "page-heading")
        top.pack_start(self.page_title, False, False, 4)
        spacer = Gtk.Box()
        top.pack_start(spacer, True, True, 0)
        self.search = Gtk.SearchEntry()
        self.search.set_placeholder_text("Search apps and spaces")
        self.search.set_size_request(260, -1)
        self.search.connect("search-changed", self._search_changed)
        top.pack_start(self.search, False, False, 0)
        self.network_status = self._label("● Checking network", "status-pill")
        top.pack_start(self.network_status, False, False, 8)
        self.clock = self._label("", "status-pill")
        top.pack_start(self.clock, False, False, 4)
        top.pack_start(self._icon_button("system-shutdown-symbolic", "Power options", self._power_menu), False, False, 0)

        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self.stack.set_transition_duration(110)
        main.pack_start(self.stack, True, True, 0)
        self._add_home()
        self._add_module_pages()
        self._add_search_page()
        self.show_module("home")

    def _label(self, text, style=None):
        item = Gtk.Label(label=text, xalign=0)
        if style:
            item.get_style_context().add_class(style)
        return item

    def _nav_button(self, icon, title, key):
        button = Gtk.Button()
        button.set_relief(Gtk.ReliefStyle.NONE)
        button.get_style_context().add_class("nav-button")
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        if len(icon) <= 2:
            glyph = Gtk.Label(label=icon)
            glyph.get_style_context().add_class("nav-glyph")
        else:
            glyph = Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.BUTTON)
        row.pack_start(glyph, False, False, 0)
        row.pack_start(Gtk.Label(label=title, xalign=0), True, True, 0)
        button.add(row)
        if key == "settings":
            button.connect("clicked", lambda *_: launch(("yassen-settings",)))
        elif key == "welcome":
            button.connect("clicked", lambda *_: launch(("yassen-welcome",)))
        else:
            button.connect("clicked", lambda *_: self.show_module(key))
        self.nav_buttons[key] = button
        return button

    def _icon_button(self, icon, label, callback):
        button = Gtk.Button()
        button.set_tooltip_text(label)
        button.set_relief(Gtk.ReliefStyle.NONE)
        button.get_style_context().add_class("icon-button")
        button.add(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.BUTTON))
        button.connect("clicked", lambda *_: callback())
        return button

    def _page(self, key, title, subtitle):
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
        box.set_margin_start(22)
        box.set_margin_end(12)
        box.set_margin_top(14)
        box.set_margin_bottom(24)
        box.pack_start(self._label(title, "page-heading"), False, False, 0)
        box.pack_start(self._label(subtitle, "page-subtitle"), False, False, 0)
        scroll.add(box)
        self.stack.add_named(scroll, key)
        return box

    def _add_home(self):
        home = self._page(
            "home", "Welcome to YASSEN ARCH",
            "Choose a workspace. Your apps and files stay on this computer unless you connect a service.",
        )
        welcome = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        welcome.get_style_context().add_class("hero-card")
        welcome.set_border_width(22)
        welcome.pack_start(self._label("One system. Six focused workspaces.", "hero-title"), False, False, 0)
        welcome.pack_start(self._label("Explore, create, code, play, and connect your tools from one desktop.", "body-text"), False, False, 0)
        home.pack_start(welcome, False, False, 0)
        home.pack_start(self._label("WORKSPACES", "eyebrow"), False, False, 0)
        flow = self._flow()
        for key, title, description, icon in MODULES:
            flow.add(self._card(title, description, icon, lambda k=key: self.show_module(k)))
        home.pack_start(flow, False, False, 0)
        install = self._card(
            "Install YASSEN ARCH", "Create a user account and install to a disk from Calamares.",
            "drive-harddisk", lambda: launch(("yassen-welcome", "--install")),
        )
        home.pack_start(install, False, False, 0)

    def _add_module_pages(self):
        for key, title, description, _icon in MODULES:
            page = self._page(key, title, description)
            if key == "ai":
                note = "Connect OpenAI or another compatible online endpoint, or a local model server. AI suggestions do not run commands or save code automatically."
            elif key == "cyber":
                note = "Use security tools only on systems you own or have explicit permission to assess. Remote scanning is never started automatically."
            elif key == "cloud":
                note = "Cloud providers are not connected by default. Review each account and backup destination before enabling sync."
            else:
                note = "Launch the tools installed for this workspace. You can add more Debian applications after installation."
            callout = self._label(note, "callout")
            callout.set_line_wrap(True)
            page.pack_start(callout, False, False, 0)
            flow = self._flow()
            for app in APPS:
                if app["module"] == key:
                    flow.add(self._card(app["title"], app["description"], app["icon"], lambda a=app: launch(a["command"])))
            page.pack_start(flow, False, False, 0)

    def _add_search_page(self):
        self.search_page = self._page("search", "Search results", "Search installed apps and YASSEN ARCH workspaces.")
        self.search_flow = self._flow()
        self.search_page.pack_start(self.search_flow, False, False, 0)

    def _flow(self):
        flow = Gtk.FlowBox()
        flow.set_selection_mode(Gtk.SelectionMode.NONE)
        flow.set_homogeneous(True)
        flow.set_min_children_per_line(1)
        flow.set_max_children_per_line(3)
        flow.set_column_spacing(12)
        flow.set_row_spacing(12)
        return flow

    def _card(self, title, description, icon, action):
        card = Gtk.Button()
        card.set_relief(Gtk.ReliefStyle.NONE)
        card.get_style_context().add_class("app-card")
        card.set_size_request(245, 140)
        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=9)
        body.set_halign(Gtk.Align.START)
        body.set_valign(Gtk.Align.START)
        body.set_margin_top(15)
        body.set_margin_bottom(14)
        body.set_margin_start(16)
        body.set_margin_end(16)
        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        head.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.DIALOG), False, False, 0)
        head.pack_start(Gtk.Label(label=title, xalign=0), True, True, 0)
        body.pack_start(head, False, False, 0)
        desc = Gtk.Label(label=description, xalign=0)
        desc.set_line_wrap(True)
        desc.set_max_width_chars(34)
        desc.get_style_context().add_class("card-description")
        body.pack_start(desc, False, False, 0)
        card.add(body)
        card.connect("clicked", lambda *_: action())
        return card

    def show_module(self, key):
        self.stack.set_visible_child_name(key)
        title = "Search results" if key == "search" else "Workspace" if key == "home" else next((m[1] for m in MODULES if m[0] == key), "Settings")
        self.page_title.set_text(title)
        for name, button in self.nav_buttons.items():
            context = button.get_style_context()
            if name == key:
                context.add_class("selected")
            else:
                context.remove_class("selected")

    def _search_changed(self, entry):
        term = entry.get_text().strip().casefold()
        if not term:
            self.show_module("home")
            return
        for child in list(self.search_flow.get_children()):
            self.search_flow.remove(child)
        matches = []
        for app in APPS:
            haystack = " ".join((app["title"], app["description"], app["module"])).casefold()
            if term in haystack:
                matches.append(self._card(app["title"], app["description"], app["icon"], lambda a=app: launch(a["command"])))
        for key, title, description, icon in MODULES:
            if term in (title + " " + description).casefold():
                matches.append(self._card(title, description, icon, lambda k=key: self.show_module(k)))
        for card in matches:
            self.search_flow.add(card)
        if not matches:
            self.search_flow.add(self._label("No matching apps. Install additional software from the Debian repositories.", "body-text"))
        self.search_flow.show_all()
        self.show_module("search")

    def _refresh_status(self):
        self.clock.set_text(datetime.datetime.now().strftime("%a %d %b · %H:%M"))
        try:
            result = subprocess.run(("nmcli", "-t", "-f", "STATE", "general"), capture_output=True, text=True, timeout=2, check=False)
            connected = result.returncode == 0 and "connected" in result.stdout.casefold()
        except (OSError, subprocess.TimeoutExpired):
            connected = False
        self.network_status.set_text("● Online" if connected else "● Offline")
        return True

    def _power_menu(self):
        menu = Gtk.Menu()
        for label, command in (("Lock screen", ("loginctl", "lock-session")), ("Restart", ("systemctl", "reboot")), ("Shut down", ("systemctl", "poweroff"))):
            item = Gtk.MenuItem(label=label)
            item.connect("activate", lambda _item, c=command: self._confirm_power(c))
            menu.append(item)
        menu.show_all()
        menu.popup_at_pointer(None)

    def _confirm_power(self, command):
        if command[0] == "loginctl":
            launch(command)
            return
        dialog = Gtk.MessageDialog(transient_for=self, flags=Gtk.DialogFlags.MODAL, message_type=Gtk.MessageType.WARNING, buttons=Gtk.ButtonsType.YES_NO, text=f"{command[1].title()} this computer?")
        dialog.format_secondary_text("Save your work before continuing.")
        answer = dialog.run()
        dialog.destroy()
        if answer == Gtk.ResponseType.YES:
            launch(command)


if __name__ == "__main__":
    Notify.init("YASSEN ARCH")
    window = YassenShell()
    window.show_all()
    Gtk.main()
