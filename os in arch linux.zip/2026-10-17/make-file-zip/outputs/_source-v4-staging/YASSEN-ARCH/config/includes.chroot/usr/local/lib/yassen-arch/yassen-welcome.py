#!/usr/bin/env python3
"""First-run welcome and safe installer entry point for YASSEN ARCH."""
import argparse
import os
import subprocess
from pathlib import Path

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

MARKER = Path.home() / ".config" / "yassen-arch" / "welcome-seen"


def launch_installer(parent):
    if not shutil_which("calamares"):
        dialog = Gtk.MessageDialog(transient_for=parent, flags=Gtk.DialogFlags.MODAL, message_type=Gtk.MessageType.ERROR, buttons=Gtk.ButtonsType.CLOSE, text="The installer is not available in this live session.")
        dialog.run(); dialog.destroy()
        return
    dialog = Gtk.MessageDialog(transient_for=parent, flags=Gtk.DialogFlags.MODAL, message_type=Gtk.MessageType.WARNING, buttons=Gtk.ButtonsType.CANCEL | Gtk.ButtonsType.CONTINUE, text="Start the YASSEN ARCH installer?")
    dialog.format_secondary_text("The installer will let you review the target disk and account details. No disk is changed until you confirm the final operation in the installer.")
    response = dialog.run(); dialog.destroy()
    if response == Gtk.ResponseType.CONTINUE:
        subprocess.Popen(("calamares",), start_new_session=True)


def shutil_which(command):
    from shutil import which
    return which(command)


class Welcome(Gtk.Window):
    def __init__(self):
        super().__init__(title="Welcome to YASSEN ARCH")
        self.set_default_size(720, 520)
        self.set_border_width(32)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
        self.add(box)
        heading = Gtk.Label(label="Welcome to YASSEN ARCH", xalign=0)
        heading.get_style_context().add_class("title-1")
        box.pack_start(heading, False, False, 0)
        intro = Gtk.Label(label="A Debian-based x86-64 desktop with focused workspaces for AI, security, creative work, coding, games, and cloud tools.", xalign=0)
        intro.set_line_wrap(True)
        box.pack_start(intro, False, False, 0)

        info = Gtk.Label(label="Try the live desktop without installing. The installer can create your account and install YASSEN ARCH to a virtual or physical disk after you review its final confirmation.", xalign=0)
        info.set_line_wrap(True)
        info.get_style_context().add_class("muted")
        box.pack_start(info, False, False, 10)

        try_button = Gtk.Button(label="Start exploring")
        try_button.set_halign(Gtk.Align.START)
        try_button.connect("clicked", lambda *_: self.destroy())
        box.pack_start(try_button, False, False, 0)
        install = Gtk.Button(label="Install YASSEN ARCH")
        install.set_halign(Gtk.Align.START)
        install.connect("clicked", lambda *_: launch_installer(self))
        box.pack_start(install, False, False, 0)
        footer = Gtk.Label(label="A live session does not save changes when the computer is shut down unless persistence is configured.", xalign=0)
        footer.set_line_wrap(True)
        footer.get_style_context().add_class("muted")
        box.pack_end(footer, False, False, 0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--first-run", action="store_true")
    parser.add_argument("--install", action="store_true")
    args = parser.parse_args()
    try:
        installer_boot = "yassen.install=1" in Path("/proc/cmdline").read_text(encoding="utf-8")
    except OSError:
        installer_boot = False
    if args.install:
        win = Welcome()
        win.show_all()
        launch_installer(win)
        win.destroy()
        return
    if installer_boot:
        win = Welcome()
        win.connect("destroy", Gtk.main_quit)
        win.show_all()
        launch_installer(win)
        Gtk.main()
        return
    if args.first_run and MARKER.exists():
        return
    MARKER.parent.mkdir(parents=True, exist_ok=True)
    MARKER.touch(exist_ok=True)
    window = Welcome()
    window.connect("destroy", Gtk.main_quit)
    window.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
