YASSEN ARCH One-Click Build

1. Extract the entire YASSEN-ARCH-One-Click-Build.zip into a new folder.
2. Double-click Build-YASSEN-ARCH.cmd. It does not need a separate PowerShell file.
3. If asked, enter the Linux password you created in Debian. Nothing appears while you type.
4. Keep the window open. The ISO, IMG, checksums, and build information are copied to Downloads\YASSEN-ARCH.
5. If the build stops, photograph the error shown above the final prompt and send it.

The helper does not write to a USB drive.
