@echo off
setlocal
title Build YASSEN ARCH boot media
echo Starting YASSEN ARCH build helper...
echo Keep this window open. If an error appears, take a photo before closing it.
echo.
set "SOURCE=%~dp0YASSEN-ARCH-Source-Project.zip"
if not exist "%SOURCE%" set "SOURCE=%USERPROFILE%\Documents\Codex\2026-10-17\make-file-zip\outputs\YASSEN-ARCH-Source-Project.zip"
if not exist "%SOURCE%" (
  echo Could not find YASSEN-ARCH-Source-Project.zip.
  echo Extract the entire One-Click Build ZIP, or keep the source ZIP beside this CMD file.
  echo Looked in: %~dp0
  goto finished
)
echo Using source: "%SOURCE%"
for /f "delims=" %%D in ('powershell -NoProfile -Command "$env:SOURCE.Substring(0,1).ToLowerInvariant()"') do set "DRIVE=%%D"
set "LINUXZIP=%SOURCE:\=/%"
set "LINUXZIP=/mnt/%DRIVE%%LINUXZIP:~2%"
set "WINOUTPUT=%USERPROFILE%\Downloads\YASSEN-ARCH"
for /f "delims=" %%D in ('powershell -NoProfile -Command "$env:WINOUTPUT.Substring(0,1).ToLowerInvariant()"') do set "OUTDRIVE=%%D"
set "LINUXOUTPUT=%WINOUTPUT:\=/%"
set "LINUXOUTPUT=/mnt/%OUTDRIVE%%LINUXOUTPUT:~2%"

echo Installing Debian build tools, then building and verifying YASSEN ARCH.
echo If asked, enter the Linux password you created for Debian. Nothing appears while you type.
wsl.exe -d Debian -- bash -lc "set -e; sudo apt update; sudo apt install -y unzip live-build xorriso mtools grub-pc-bin grub-efi-amd64-bin syslinux-common isolinux debootstrap squashfs-tools dosfstools fdisk; mkdir -p $HOME/yassen-arch-build; unzip -o '%LINUXZIP%' -d $HOME/yassen-arch-build; cd $HOME/yassen-arch-build/YASSEN-ARCH; sudo bash scripts/build.sh; bash scripts/verify-artifacts.sh; mkdir -p '%LINUXOUTPUT%'; cp dist/YASSEN-ARCH-x86_64.iso dist/YASSEN-ARCH-x86_64.img dist/SHA256SUMS dist/BUILD_INFO.txt '%LINUXOUTPUT%/'"
if errorlevel 1 echo Build stopped with an error. Take a photo of the message above.
if errorlevel 1 goto finished
echo.
echo Build and verification completed. Files are in Downloads\YASSEN-ARCH.
echo No USB drive was written.
:finished
echo.
echo Press any key to close this window.
pause >nul
