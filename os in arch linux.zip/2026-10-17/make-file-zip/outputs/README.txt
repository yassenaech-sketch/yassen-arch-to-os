Build YASSEN ARCH without copying commands:
1. Extract all files from YASSEN-ARCH-Build-Kit.zip into one folder.
2. Double-click Build-YASSEN-ARCH.cmd.
3. Keep the black window open. If asked, type the Linux password you created in Debian. Nothing appears while you type.
4. Wait for the build and verification to finish. The ISO and IMG should be saved under Downloads\YASSEN-ARCH.
5. If it stops, leave the window open and send a photo of the message.

This script builds in Debian WSL and never writes to a USB drive.
