$ErrorActionPreference = 'Stop'
$BuildFailed = $false

$Distro = 'Debian'
$SourceZip = Join-Path $PSScriptRoot 'YASSEN-ARCH-Source-Project.zip'
$WindowsOutput = Join-Path $env:USERPROFILE 'Downloads\YASSEN-ARCH'

try {
  if (-not (Test-Path -LiteralPath $SourceZip -PathType Leaf)) {
    throw "The source archive is missing beside this script: $SourceZip"
  }
  $null = Get-Command wsl.exe -ErrorAction Stop

  Write-Host 'Checking the Debian WSL installation...'
  $LinuxHome = (& wsl.exe -d $Distro -- bash -lc 'printf "%s" "$HOME"' 2>&1 | Out-String).Trim()
  if ($LASTEXITCODE -ne 0 -or -not $LinuxHome.StartsWith('/')) {
    throw "Could not start Debian WSL. Open Debian once from Start and finish its setup. Details: $LinuxHome"
  }

  $Drive = $SourceZip.Substring(0, 1).ToLowerInvariant()
  $LinuxZip = '/mnt/' + $Drive + $SourceZip.Substring(2).Replace('\', '/')
  $LinuxOutput = '/mnt/' + $WindowsOutput.Substring(0, 1).ToLowerInvariant() + $WindowsOutput.Substring(2).Replace('\', '/')
  $LinuxProject = "$LinuxHome/yassen-arch-build"

  Write-Host 'Installing the Debian tools needed to build YASSEN ARCH.'
  Write-Host 'If asked, enter the Linux password created during Debian setup. The password will not appear as you type.'
  & wsl.exe -d $Distro -- bash -lc 'sudo apt update && sudo apt install -y unzip live-build xorriso mtools grub-pc-bin grub-efi-amd64-bin syslinux-common isolinux debootstrap squashfs-tools dosfstools fdisk'
  if ($LASTEXITCODE -ne 0) { throw 'Installing Debian build tools failed.' }

  Write-Host 'Building and verifying YASSEN ARCH. This downloads many packages and can take a long time.'
  $LinuxCommand = "set -e; mkdir -p '$LinuxProject'; unzip -o '$LinuxZip' -d '$LinuxProject'; cd '$LinuxProject/YASSEN-ARCH'; sudo bash scripts/build.sh; bash scripts/verify-artifacts.sh; mkdir -p '$LinuxOutput'; cp dist/YASSEN-ARCH-x86_64.iso dist/YASSEN-ARCH-x86_64.img dist/SHA256SUMS dist/BUILD_INFO.txt '$LinuxOutput/'"
  & wsl.exe -d $Distro -- bash -lc $LinuxCommand
  if ($LASTEXITCODE -ne 0) { throw 'The build or verification failed. Photograph the error above and send it for help.' }

  Write-Host ''
  Write-Host "Build and verification completed. Files are in: $WindowsOutput"
  Write-Host 'No USB drive was written.'
}
catch {
  Write-Host ''
  Write-Host "Build stopped: $($_.Exception.Message)" -ForegroundColor Red
  $BuildFailed = $true
}

if ($BuildFailed) { exit 1 }
exit 0
