# VIB OS design notes

## First milestone

VIB OS starts as a small x86 learning project. The current BIOS demo initializes a real-mode stack, writes a welcome screen through BIOS video services, reads the keyboard through BIOS keyboard services, and echoes input.

## Boot flow

1. Legacy BIOS reads the El Torito boot image from the ISO.
2. The boot sector initializes real-mode segments and the stack.
3. BIOS text services display the VIB OS screen.
4. BIOS keyboard services read and echo input.

## Next milestones

1. Load a second-stage program from disk.
2. Enter protected mode and load a C kernel.
3. Add a VGA console, interrupt table, timer, and keyboard driver.
4. Add documented read-only ISO support and a simple filesystem.
5. Build an installer that targets a virtual disk.
6. Add UEFI and hybrid USB boot only after implementing and testing those boot paths.

## Compatibility

This release supports legacy BIOS boot from an El Torito ISO. It is intended for VirtualBox with EFI disabled. UEFI-only systems and direct USB flashing are not supported. Hardware varies, so it should not be described as bootable on every PC.
