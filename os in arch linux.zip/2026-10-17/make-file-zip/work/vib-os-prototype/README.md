# VIB OS — BIOS boot prototype

This is a tiny, bootable x86 legacy-BIOS learning demo. It starts in 16-bit real mode, displays a welcome message, reads keyboard input, and echoes keys. Press Enter for a message; Esc redraws the screen.

The ISO is El Torito BIOS-bootable and suitable for a VirtualBox VM configured for legacy BIOS. It is a prototype, not a complete operating system or installer. It does not support UEFI, and this ISO is not a hybrid USB image for direct flashing.

## Build from source

On Linux or WSL, install NASM and xorriso, then run:

```sh
./build.sh
```

The script writes `outputs/vib-os.iso`. To try it in VirtualBox, create a new VM with an empty virtual disk, attach the ISO as an optical drive, and keep EFI disabled.

## Files

- `boot/boot.asm` — readable 16-bit BIOS boot source.
- `image/boot/vib-eltorito.bin` — 2048-byte El Torito boot image included in the supplied ISO.
- `build.sh` — assembles the boot image and creates an El Torito ISO.
- `DESIGN.md` — design notes and next development milestones.
