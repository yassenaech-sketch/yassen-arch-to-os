BITS 16
ORG 0x7C00

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti
    mov ax, 0x0003
    int 0x10

    mov si, banner
.print_banner:
    lodsb
    test al, al
    jz .prompt
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    jmp .print_banner

.prompt:
    mov si, prompt_text
.print_prompt:
    lodsb
    test al, al
    jz .read_key
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    jmp .print_prompt

.read_key:
    xor ax, ax
    int 0x16
    cmp al, 0x0D
    je .enter
    cmp al, 0x1B
    je .restart
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    jmp .read_key

.enter:
    mov si, newline
.print_newline:
    lodsb
    test al, al
    jz .restart
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    jmp .print_newline

.restart:
    jmp start

banner db 'VIB OS - x86 BIOS boot prototype',13,10,13,10
       db 'This is a bootable learning demo, not a full operating system.',13,10,0
prompt_text db 'Press Enter for a message, Esc to redraw, or type a key: ',0
newline db 'VIB OS is alive.',13,10,0

times 510-($-$$) db 0
dw 0xAA55
