#!/usr/bin/env sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
OUT="$ROOT/outputs"
IMG="$ROOT/image/boot"
mkdir -p "$OUT" "$IMG"
command -v nasm >/dev/null 2>&1 || { echo 'Missing dependency: nasm' >&2; exit 1; }
command -v xorriso >/dev/null 2>&1 || { echo 'Missing dependency: xorriso' >&2; exit 1; }

nasm -f bin "$ROOT/boot/boot.asm" -o "$IMG/boot.raw"
size=$(wc -c < "$IMG/boot.raw" | tr -d ' ')
[ "$size" = 512 ] || { echo "Expected 512-byte boot sector, got $size" >&2; exit 1; }
cat "$IMG/boot.raw" > "$IMG/vib-eltorito.bin"
# El Torito loads four 512-byte virtual sectors for this no-emulation image.
dd if=/dev/zero bs=512 count=3 >> "$IMG/vib-eltorito.bin" 2>/dev/null
xorriso -as mkisofs -R -J -V VIB_OS \
  -b boot/vib-eltorito.bin -no-emul-boot -boot-load-size 4 \
  -o "$OUT/vib-os.iso" "$ROOT/image"
printf 'Created %s\n' "$OUT/vib-os.iso"

