# Package manifests

The package manifests consumed by live-build are kept in `config/package-lists/` so live-build can ingest them directly. This directory is reserved for locally built `.deb` packages or reviewed package-source metadata if Vib Shell is later packaged independently.
