#!/usr/bin/env python3
"""Minimal, dependency-light GTK shell for the Vib OS Openbox session."""
import datetime
import subprocess
import sys
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Notify", "0.7")
from gi.repository import Gtk, GLib, Gdk, Notify

Notify.init("Vib Shell")

def run(*command):
    try:
        subprocess.Popen(command, start_new_session=True)
    except FileNotFoundError:
        Notify.Notification.new("Vib OS", f"Could not start {command[0]}").show()

def button(icon, label, action):
    b = Gtk.Button()
    b.get_style_context().add_class("vib-button")
    row = Gtk.Box(spacing=7)
    row.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.BUTTON), False, False, 0)
    if label:
        row.pack_start(Gtk.Label(label=label), False, False, 0)
    b.add(row)
    b.connect("clicked", lambda *_: action())
    return b

class VibShell:
    def __init__(self):
        css = Gtk.CssProvider()
        css.load_from_path("/usr/local/lib/vib-os/vib-gtk.css")
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self.top = self.panel(Gtk.WindowType.TOPLEVEL, "vib-topbar", 42)
        top_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        self.top.add(top_row)
        brand = Gtk.Label(label="VIB")
        brand.get_style_context().add_class("vib-title")
        top_row.pack_start(brand, False, False, 14)
        top_row.pack_start(button("view-grid-symbolic", "Apps", self.app_menu), False, False, 0)
        self.clock = Gtk.Label()
        self.clock.get_style_context().add_class("vib-muted")
        top_row.pack_end(button("system-shutdown-symbolic", "", self.power_menu), False, False, 8)
        top_row.pack_end(button("preferences-system-symbolic", "", lambda: run("vib-settings")), False, False, 0)
        top_row.pack_end(button("preferences-desktop-notification-symbolic", "", self.notify), False, False, 0)
        top_row.pack_end(self.clock, False, False, 12)
        self.dock = self.panel(Gtk.WindowType.TOPLEVEL, "vib-dock", 70)
        dock_row = Gtk.Box(spacing=4)
        self.dock.add(dock_row)
        for icon, label, action in [
            ("system-file-manager", "Files", lambda: run("thunar")),
            ("utilities-terminal", "Terminal", lambda: run("xfce4-terminal")),
            ("preferences-system", "Settings", lambda: run("vib-settings")),
            ("help-browser", "Welcome", lambda: run("vib-welcome")),
        ]:
            dock_row.pack_start(button(icon, label, action), False, False, 0)
        GLib.timeout_add_seconds(1, self.update_clock)
        self.update_clock()

    def panel(self, kind, css_class, height):
        window = Gtk.Window(type=kind)
        window.set_decorated(False)
        window.set_keep_above(True)
        window.set_skip_taskbar_hint(True)
        window.set_type_hint(Gdk.WindowTypeHint.DOCK)
        window.get_style_context().add_class(css_class)
        window.connect("destroy", Gtk.main_quit)
        screen = Gdk.Screen.get_default()
        if css_class == "vib-dock":
            window.set_default_size(430, height)
            window.move(max(0, (screen.get_width() - 430) // 2), screen.get_height() - height - 20)
        else:
            window.move(0, 0)
            window.set_default_size(screen.get_width(), height)
        window.show_all()
        return window

    def update_clock(self):
        self.clock.set_text(datetime.datetime.now().strftime("%a %d %b  %H:%M"))
        return True

    def notify(self):
        Notify.Notification.new("Vib Shell", "You are all caught up.", "dialog-information").show()

    def app_menu(self):
        menu = Gtk.Menu()
        for label, command in [("Files", "thunar"), ("Terminal", "xfce4-terminal"), ("Settings", "vib-settings"), ("Welcome", "vib-welcome")]:
            item = Gtk.MenuItem(label=label)
            item.connect("activate", lambda _, c=command: run(c))
            menu.append(item)
        menu.show_all()
        menu.popup_at_pointer(None)

    def power_menu(self):
        menu = Gtk.Menu()
        for label, command in [("Restart", ["systemctl", "reboot"]), ("Power off", ["systemctl", "poweroff"])]:
            item = Gtk.MenuItem(label=label)
            item.connect("activate", lambda _, c=command: run(*c))
            menu.append(item)
        menu.show_all()
        menu.popup_at_pointer(None)

if __name__ == "__main__":
    VibShell()
    Gtk.main()
