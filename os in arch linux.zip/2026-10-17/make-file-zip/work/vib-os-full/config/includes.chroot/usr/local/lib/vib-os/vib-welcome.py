#!/usr/bin/env python3
import argparse, os, gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

class Welcome(Gtk.Window):
    def __init__(self):
        super().__init__(title="Welcome to Vib OS")
        self.set_default_size(680, 430); self.set_border_width(34)
        box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18); self.add(box)
        heading=Gtk.Label(label="Welcome to Vib OS", xalign=0); heading.get_style_context().add_class("title-1"); box.pack_start(heading, False, False, 0)
        box.pack_start(Gtk.Label(label="A lightweight Debian live desktop, ready to explore or install.", xalign=0), False, False, 0)
        for title, text, command in [("Try the desktop", "Open files, settings, or a terminal without changing a disk.", "thunar"), ("Install Vib OS", "Launch Calamares. Disk changes happen only after its final confirmation page.", "calamares")]:
            b=Gtk.Button(label=title); b.set_tooltip_text(text); b.connect("clicked", lambda _, c=command: os.system(c + " &")); box.pack_start(b, False, False, 0)
        close=Gtk.Button(label="Start exploring"); close.connect("clicked", lambda *_: self.destroy()); box.pack_end(close, False, False, 0)

args=argparse.ArgumentParser(); args.add_argument("--first-run", action="store_true"); parsed=args.parse_args()
marker=os.path.expanduser("~/.config/vib-welcome-seen")
if "vib.install=1" in open("/proc/cmdline", encoding="utf-8").read():
    # This starts the graphical installer only; Calamares still requires its own final disk confirmation.
    os.system("calamares &")
if not parsed.first_run or not os.path.exists(marker):
    os.makedirs(os.path.dirname(marker), exist_ok=True); open(marker,"a").close()
    w=Welcome(); w.connect("destroy", Gtk.main_quit); w.show_all(); Gtk.main()
