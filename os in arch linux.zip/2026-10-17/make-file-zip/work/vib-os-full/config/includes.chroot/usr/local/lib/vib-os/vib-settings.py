#!/usr/bin/env python3
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk

class Settings(Gtk.Window):
    def __init__(self):
        super().__init__(title="Vib Settings")
        self.set_border_width(24); self.set_default_size(560, 360)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14); self.add(box)
        title = Gtk.Label(label="Vib Settings", xalign=0); title.get_style_context().add_class("title-1"); box.pack_start(title, False, False, 0)
        box.pack_start(Gtk.Label(label="Choose a theme for Vib Shell. Changes take effect for newly opened applications.", xalign=0), False, False, 0)
        switch = Gtk.Switch(); row = Gtk.Box(spacing=12); row.pack_start(Gtk.Label(label="Dark theme", xalign=0), True, True, 0); row.pack_end(switch, False, False, 0); box.pack_start(row, False, False, 0)
        box.pack_start(Gtk.Separator(), False, False, 4)
        for text in ["Network is managed by NetworkManager.", "Display, sound, and keyboard tools are available from the app menu.", "The installer always requires confirmation before changing disks."]:
            box.pack_start(Gtk.Label(label=text, xalign=0), False, False, 0)

win = Settings(); win.connect("destroy", Gtk.main_quit); win.show_all(); Gtk.main()
