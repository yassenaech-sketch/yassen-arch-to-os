# Third-party notices

Vib OS is assembled from Debian packages. Their source and license information is available in `/usr/share/doc/<package>/copyright` on a built system.

| Component | License / source |
| --- | --- |
| Debian GNU/Linux and live-build | Debian Free Software Guidelines; https://www.debian.org/legal/licenses/ |
| Openbox | GPL-2.0-or-later |
| GTK / PyGObject | LGPL-2.1-or-later |
| Papirus icon theme | GPL-3.0-or-later |
| DejaVu fonts | Bitstream Vera-derived permissive license |
| Calamares | GPL-3.0-or-later |

No logos, screenshots, or third-party artwork from the private user archive are distributed by this repository.
