# Flashing a Vib OS USB

The image is a whole-device image. **Flashing erases the selected USB drive.** Do not unpack it or copy its files onto a formatted stick.

1. Compare the downloaded checksum with `dist/SHA256SUMS`.
2. In Balena Etcher, choose `VibOS-x86_64.img`, select the removable USB drive, and flash.
3. In Rufus, choose the image and select **DD mode** if prompted.
4. On Linux, first identify the removable device carefully (for example `/dev/sdX`), then run:

```bash
sudo dd if=dist/VibOS-x86_64.img of=/dev/sdX bs=4M conv=fsync status=progress
```

Replace `/dev/sdX` with the whole USB device, never a partition such as `/dev/sdX1`. The command permanently overwrites that device.

Vib OS targets normal 64-bit BIOS and UEFI systems. Secure Boot is not included in this project; disable it where necessary. It does not promise compatibility with every PC.
