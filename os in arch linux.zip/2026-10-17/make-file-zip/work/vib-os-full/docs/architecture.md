# Architecture

```text
UEFI firmware / legacy BIOS
        │
 GRUB EFI + Syslinux/GRUB BIOS paths in a live-build hybrid ISO
        │
 Debian stable kernel + live-boot + squashfs root
        │
 Openbox session → Vib Shell (GTK top bar/dock) → Debian applications
        │                                   └→ Calamares installer
```

`live-build` owns boot-media creation and package installation. `config/includes.chroot` injects the Vib Shell programs into the live root. A live user receives the Openbox autostart file from `/etc/skel`; the welcome screen exposes a Calamares launch button but does not start installation itself.

The raw `.img` is intentionally a byte-for-byte copy of the generated hybrid ISO. That makes it safe to flash as a whole-device image and preserves the ISO's BIOS/UEFI boot catalog. The verification script records its partition/El Torito structure; it does not falsely claim a partition layout before inspecting the actual built artifact.
