# Testing record and release checklist

## Automated by the project

| Check | Command | Result in this workspace |
| --- | --- | --- |
| Shell-script syntax | `bash -n scripts/*.sh` | Passed on Windows Git Bash |
| Python bytecode syntax | `python3 -m py_compile …` | Not run: no usable Python interpreter in this workspace |
| Checksums exist and match | `./scripts/verify-artifacts.sh` | Not run: artifacts not built |
| ISO BIOS boot | `./scripts/run-qemu-bios.sh` | Not run: no Debian build host/QEMU artifact |
| ISO UEFI boot | `./scripts/run-qemu-uefi.sh` | Not run: no Debian build host/OVMF artifact |
| Hybrid boot records | `xorriso -report_el_torito plain` | Not run: no ISO artifact |
| USB partition report/EFI path | `fdisk -l` and `mdir` in verifier | Not run: no image artifact |
| VirtualBox install safety | manual checklist in `docs/virtualbox.md` | Not run |

## Release acceptance

After a successful build, record the exact host, output checksums, and screenshots/logs from both QEMU modes. Test Calamares only against a disposable VM disk. Confirm that its final confirmation page names the target disk and warns that data will be changed. Do not flash a physical USB or install onto a physical disk as part of automated testing.
