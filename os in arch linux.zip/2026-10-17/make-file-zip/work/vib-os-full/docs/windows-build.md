# Build Vib OS on Windows with WSL2 Debian

The live-build pipeline must run in Debian. PowerShell cannot create this Linux boot media natively.

## 1. Install WSL2 Debian

Open **PowerShell as Administrator** and run:

```powershell
wsl --install -d Debian
```

Restart Windows if asked, then launch **Debian** from the Start menu and create its Linux username/password.

## 2. Install the build tools

In the Debian terminal:

```bash
sudo apt update
sudo apt install -y live-build xorriso mtools grub-pc-bin grub-efi-amd64-bin syslinux-common isolinux debootstrap squashfs-tools dosfstools fdisk git
```

## 3. Build the ISO and USB image

Run these commands in the Debian terminal:

```bash
cd /mnt/c/Users/moham/Documents/Codex/2026-10-16/files-mentioned-by-the-user-create/outputs/vib-os
sudo ./scripts/build.sh
./scripts/verify-artifacts.sh
```

The resulting files appear in the Windows folder:

```text
C:\Users\moham\Documents\Codex\2026-10-16\files-mentioned-by-the-user-create\outputs\vib-os\dist\
```

Expected outputs are `VibOS-x86_64.iso`, `VibOS-x86_64.img`, `SHA256SUMS`, and `BUILD_INFO.txt`. The build may download several gigabytes of Debian packages and needs free disk space. If any command fails, keep its full error output; do not rename an incomplete file to look like a finished ISO or IMG.

## 4. Try the ISO in VirtualBox

Create a VM with Linux/Debian 64-bit, 2 CPUs, 4 GB RAM, and a 32 GB virtual disk. Attach `dist/VibOS-x86_64.iso` as the optical drive. Try it live first. The installer should not modify a disk until you review and confirm the final disk operation.

## 5. Flash the USB image

Only after `./scripts/verify-artifacts.sh` succeeds, choose `dist/VibOS-x86_64.img` in Balena Etcher or Rufus with **DD mode**. Confirm the destination is the intended USB drive: writing the image erases that drive. Never copy the image's files onto an already formatted USB stick.
