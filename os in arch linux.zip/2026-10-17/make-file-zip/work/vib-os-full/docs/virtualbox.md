# VirtualBox

Create a VM with 2 CPUs, 4 GB RAM, 32 GB virtual disk, and the Vib OS ISO attached as an optical disk. Use `scripts/create-virtualbox-vm.ps1` on Windows where VirtualBox is installed:

```powershell
.\scripts\create-virtualbox-vm.ps1
```

Add `-EnableEfi` for a UEFI test. Boot the ISO, choose **Try Vib OS**, then select **Install Vib OS** from the welcome screen. Review Calamares partitioning and stop at its final confirmation page during the safety test; it must never change a disk merely by reaching the installer.
