# Design reference

## Source boundary

The user-supplied archive is a private, multi-archive collection. Its top level contains software/security archives rather than an unambiguous licensed image pack. It was treated as context only; no archive instructions were executed, no files were copied into Vib OS, and no third-party branding or artwork was reused.

## Vib visual system

The implemented direction is deliberately original and modest:

| Element | Implementation |
| --- | --- |
| Desktop | Quiet dark charcoal canvas with a compact top bar and centered floating dock |
| Accent | Violet (`#7B61FF`) hover and focus treatment |
| Typography | DejaVu Sans, included in Debian and broadly readable at 1024×768 |
| Icons | Papirus via freedesktop icon names; no copied product icons |
| Panels | Soft contrast, 12–18px radii, sparse controls |
| Motion | No required animation; GTK respects desktop accessibility settings |

The Shell uses actual GTK controls rather than composited screenshots, so its controls remain accessible and scale to high-DPI displays. When a separately licensed reference pack is available, add it to `assets/reference-images.zip`, review it manually, and update this document with a specific mapping before redistribution.
