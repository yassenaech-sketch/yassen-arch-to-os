# Vib OS

Vib OS is a lightweight Debian live desktop for standard 64-bit x86 PCs. It targets legacy BIOS and UEFI boot, and can be installed in VirtualBox from its ISO. It cannot be promised to boot on every PC; Secure Boot is not configured.

## Current status

This folder contains the source project and a ready-to-paste Antigravity prompt. No ISO, USB image, checksum, or build metadata has been generated. The Windows host could not access a running WSL Debian distribution, and the required Debian live-build environment is not available here. Do not flash an image until the build completes and the generated checksums are verified.

## Build on this Windows PC

Follow [the Windows build guide](docs/windows-build.md). In short, install WSL2 Debian, then run from the Debian terminal:

```bash
sudo apt update
sudo apt install -y live-build xorriso mtools grub-pc-bin grub-efi-amd64-bin syslinux-common isolinux debootstrap squashfs-tools dosfstools fdisk git
cd /mnt/c/Users/moham/Documents/Codex/2026-10-16/files-mentioned-by-the-user-create/outputs/vib-os
sudo ./scripts/build.sh
```

The build is expected to create `dist/VibOS-x86_64.iso`, `dist/VibOS-x86_64.img`, `dist/SHA256SUMS`, and `dist/BUILD_INFO.txt`. Then verify them with `./scripts/verify-artifacts.sh`.

## Project contents

- Debian live-build configuration for amd64 and a BIOS/UEFI hybrid ISO
- Openbox desktop with the GTK Vib Shell panel, launcher, settings, and welcome app
- Calamares installer integration with confirmation before disk changes
- Scripts and docs for building, verifying, testing in QEMU, VirtualBox setup, and USB flashing
- [Antigravity IDE prompt](docs/antigravity-prompt.md)

## Reference files

The supplied ZIP is a multi-gigabyte collection of nested software archives, not a licensed visual reference pack. Its contents were not executed or copied into the project. The pasted text file includes the requested OS specification plus prior conversation; only the user's request and relevant requirements were used. See [design-reference.md](docs/design-reference.md).

## Compatibility and safe flashing

Target standard 64-bit x86 BIOS/UEFI systems. Very new Wi-Fi, unusual storage controllers, Secure Boot, and 32-bit machines may need additional work. After a successful build, write the `.img` as a whole-device image with Rufus in DD mode, Balena Etcher, or a carefully checked `dd` command. This erases the selected USB drive; see [flashing-usb.md](docs/flashing-usb.md).
