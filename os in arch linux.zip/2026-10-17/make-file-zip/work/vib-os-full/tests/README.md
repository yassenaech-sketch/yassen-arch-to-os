# Test assets

`scripts/verify-artifacts.sh` is the artifact-structure check. The QEMU launchers in `scripts/` are the boot-test harnesses. Keep release logs, screenshots, and any VM-only installer observations here only when they contain no private disk data.

Suggested release evidence:

- `qemu-bios.txt` and `qemu-uefi.txt`
- screenshots of the Vib Shell at 1024×768
- confirmation that Calamares reached its final confirmation page in a disposable VM
