# Vib Shell source

Vib Shell is a small GTK/PyGObject desktop shell for the Openbox session. The runtime sources are staged from `config/includes.chroot/usr/local/lib/vib-os/` because that is the location consumed by Debian `live-build`.

- `vib-shell.py`: dock, top bar, launcher, notifications, clock, and power menu
- `vib-settings.py`: compact settings window
- `vib-welcome.py`: safe first-run welcome and Calamares launch surface
- `vib-gtk.css`: shell visual tokens
