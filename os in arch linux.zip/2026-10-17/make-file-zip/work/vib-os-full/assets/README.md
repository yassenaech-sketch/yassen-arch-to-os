# Visual inputs

Place an explicitly licensed `reference-images.zip` here only after reviewing it. This path is ignored by Git, because private user-provided media must not be redistributed. Images guide visual decisions; they are not copied into the OS.
