#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
command -v qemu-system-x86_64 >/dev/null || { echo "Install qemu-system-x86" >&2; exit 2; }
exec qemu-system-x86_64 -m 4096 -smp 2 -cdrom "$ROOT/dist/VibOS-x86_64.iso" -boot d -enable-kvm
