[CmdletBinding()]
param(
  [string]$Name = 'Vib OS',
  [string]$IsoPath = (Join-Path $PSScriptRoot '..\dist\VibOS-x86_64.iso'),
  [switch]$EnableEfi
)
$ErrorActionPreference = 'Stop'
$vbox = Get-Command VBoxManage.exe -ErrorAction Stop
$iso = (Resolve-Path $IsoPath).Path
& $vbox.Source createvm --name $Name --register
& $vbox.Source modifyvm $Name --ostype Debian_64 --memory 4096 --cpus 2 --vram 128 --boot1 dvd --boot2 disk --firmware $(if ($EnableEfi) {'efi'} else {'bios'})
& $vbox.Source createmedium disk --filename "$PWD\$Name.vdi" --size 32768 --format VDI
& $vbox.Source storagectl $Name --name SATA --add sata --controller IntelAhci
& $vbox.Source storageattach $Name --storagectl SATA --port 0 --device 0 --type hdd --medium "$PWD\$Name.vdi"
& $vbox.Source storagectl $Name --name IDE --add ide
& $vbox.Source storageattach $Name --storagectl IDE --port 0 --device 0 --type dvddrive --medium $iso
Write-Host "Created $Name. Start it in VirtualBox and choose Install Vib OS from the live desktop."
