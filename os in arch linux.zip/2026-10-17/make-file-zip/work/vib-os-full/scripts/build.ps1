[CmdletBinding()]
param([string]$Distribution = 'Debian')
$ErrorActionPreference = 'Stop'

if (-not (Get-Command wsl.exe -ErrorAction SilentlyContinue)) {
  throw 'WSL2 is not installed. Open PowerShell as Administrator and run: wsl --install -d Debian. Restart if Windows asks, then rerun this script.'
}

$drive = $PSScriptRoot.Substring(0, 1).ToLowerInvariant()
$linuxPath = "/mnt/$drive" + $PSScriptRoot.Substring(2).Replace('\', '/')

Write-Host "Vib OS must be built in Debian live-build (not natively in PowerShell)."
Write-Host "If Debian is not installed yet, run in Administrator PowerShell: wsl --install -d $Distribution"
Write-Host "Then open Debian from Start and run:"
Write-Host '  sudo apt update'
Write-Host '  sudo apt install -y live-build xorriso mtools grub-pc-bin grub-efi-amd64-bin syslinux-common isolinux debootstrap squashfs-tools dosfstools fdisk git'
Write-Host "  cd '$linuxPath'"
Write-Host '  sudo ./scripts/build.sh'
Write-Host 'After the build, verify with: ./scripts/verify-artifacts.sh'
