#!/usr/bin/env bash
# Build Vib OS from a Debian stable / WSL2 Debian environment.
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

need() { command -v "$1" >/dev/null 2>&1 || { echo "Missing required tool: $1" >&2; exit 2; }; }
[[ "$(id -u)" -eq 0 ]] || { echo "Run with sudo: sudo ./scripts/build.sh" >&2; exit 2; }
need lb; need xorriso; need sha256sum; need git

mkdir -p build dist
rm -rf build/live-build
cp -a config build/live-build/config
cd build/live-build

lb config noauto \
  --architectures amd64 \
  --distribution trixie \
  --archive-areas "main contrib non-free-firmware" \
  --binary-images iso-hybrid \
  --bootloaders "grub-efi syslinux" \
  --firmware-binary true \
  --debian-installer live \
  --memtest memtest86+ \
  --apt-indices false \
  --image-name VibOS \
  --iso-application "Vib OS" \
  --iso-publisher "Vib OS contributors" \
  --iso-volume "VIB_OS"

lb build

ISO="$(find . -maxdepth 1 -type f \( -name '*.hybrid.iso' -o -name '*.iso' \) | head -n1)"
[[ -n "$ISO" && -f "$ISO" ]] || { echo "live-build completed without an ISO" >&2; exit 1; }
cp "$ISO" "$ROOT/dist/VibOS-x86_64.iso"
"$ROOT/scripts/make-usb-image.sh" "$ROOT/dist/VibOS-x86_64.iso" "$ROOT/dist/VibOS-x86_64.img"

cd "$ROOT"
sha256sum dist/VibOS-x86_64.iso dist/VibOS-x86_64.img > dist/SHA256SUMS
{
  echo "name=Vib OS"
  echo "distribution=Debian trixie"
  echo "architecture=amd64"
  echo "built_at_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "git_revision=$(git rev-parse --verify HEAD 2>/dev/null || echo uncommitted-source)"
  echo "live_build=$(lb --version | head -n1)"
  echo "kernel=$(dpkg-query -W -f='${Version}' linux-image-amd64 2>/dev/null || echo resolved-in-chroot)"
  echo "configuration_sha256=$(find config -type f -print0 | sort -z | xargs -0 sha256sum | sha256sum | cut -d' ' -f1)"
} > dist/BUILD_INFO.txt

"$ROOT/scripts/verify-artifacts.sh"
echo "Build complete: $ROOT/dist/VibOS-x86_64.iso and $ROOT/dist/VibOS-x86_64.img"
