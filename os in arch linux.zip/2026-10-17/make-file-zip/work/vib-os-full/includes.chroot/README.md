# Live root filesystem includes

The authoritative live-build include tree is `config/includes.chroot/`; `live-build` copies it into the live root filesystem. It contains Vib Shell, its GTK CSS, and the Openbox autostart file. This compatibility directory makes that source location explicit without maintaining a second divergent copy.
